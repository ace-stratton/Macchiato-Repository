/*!
********************************************************************************************
* @file FP_SharpProtocolServer.c
* @brief ESSA Stack server-side implementation
********************************************************************************************
* @version           interface Sharp v0.3
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SharpProtocolServer.h"
#include "FP_common/FP_ProtocolServerCommon.h"

#define Sharp_PROTOCOL_VERSION_MAJOR   ((uint8_t) 0)
#define Sharp_PROTOCOL_VERSION_MINOR   ((uint8_t) 3)

/**********************************************************************
 *
 *  Local type definitions
 *
 **********************************************************************/
typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SharpgetHealthInfoProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpgetHealthInfoResponseData_t data;
} PACKED_STRUCT SharpgetHealthInfoProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SharpgetSHIPInfoProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpgetSHIPInfoResponseData_t data;
} PACKED_STRUCT SharpgetSHIPInfoProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetDetectorPowerRequestData_t data;
} PACKED_STRUCT SharpsetDetectorPowerProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetDetectorPowerResponseData_t data;
} PACKED_STRUCT SharpsetDetectorPowerProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpTimeRequestData_t data;
} PACKED_STRUCT SharpsetSharpTimeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpTimeResponseData_t data;
} PACKED_STRUCT SharpsetSharpTimeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpDateRequestData_t data;
} PACKED_STRUCT SharpsetSharpDateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpDateResponseData_t data;
} PACKED_STRUCT SharpsetSharpDateProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SharpgetSharpTimeDateProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpgetSharpTimeDateResponseData_t data;
} PACKED_STRUCT SharpgetSharpTimeDateProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
} PACKED_STRUCT SharpgetSharpModeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpgetSharpModeResponseData_t data;
} PACKED_STRUCT SharpgetSharpModeProtocolResponseData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpModeRequestData_t data;
} PACKED_STRUCT SharpsetSharpModeProtocolRequestData_t;

typedef struct {
    ESSA_Stack_FP_MsgHdr_t hdr;
    SharpsetSharpModeResponseData_t data;
} PACKED_STRUCT SharpsetSharpModeProtocolResponseData_t;


/**********************************************************************
 *
 *  Static methods declarations
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getHealthInfoReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getSHIPInfoReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setDetectorPowerReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setSharpTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setSharpDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getSharpTimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_getSharpModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);
static void fs_setSharpModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo);

/**********************************************************************
 *
 *  Public variable definitions
 *
 **********************************************************************/
const ESSA_Stack_FunctionProtocolInfo_t FP_SharpProtocolServerInfo = {
    .u16ProtocolId    = ES_SAT_FUNC_PROTOCOL_ID_SHARP,
    .pfDataHandlerCbk = fs_HandleData
};

/**********************************************************************
 *
 *  Static variable definitions
 *
 **********************************************************************/
static Sharp_ServerApi_t *pSrvApiHnd = NULL;

static const ProtocolFuncArrayEntry_t fs_aFuncArray[] = {
    { SHARP_GETHEALTHINFO_FUNC_ID, fs_getHealthInfoReq },
    { SHARP_GETSHIPINFO_FUNC_ID, fs_getSHIPInfoReq },
    { SHARP_SETDETECTORPOWER_FUNC_ID, fs_setDetectorPowerReq },
    { SHARP_SETSHARPTIME_FUNC_ID, fs_setSharpTimeReq },
    { SHARP_SETSHARPDATE_FUNC_ID, fs_setSharpDateReq },
    { SHARP_GETSHARPTIMEDATE_FUNC_ID, fs_getSharpTimeDateReq },
    { SHARP_GETSHARPMODE_FUNC_ID, fs_getSharpModeReq },
    { SHARP_SETSHARPMODE_FUNC_ID, fs_setSharpModeReq }
};

/**********************************************************************
 *
 *  Static methods implementation
 *
 **********************************************************************/
static bool fs_HandleData(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    ESSA_Stack_FP_MsgHdr_t *pHdr = NULL;
    bool bIsFuncSupported = false;
    uint8_t i;

    // Basic header validity check
    if ((fp_DataInfo == NULL) ||
        (fp_DataInfo->u16DataSize < sizeof(ESSA_Stack_FP_MsgHdr_t)) ||
        (fp_DataInfo->pu8Data == NULL))
    {
        return false;
    }

    pHdr = (ESSA_Stack_FP_MsgHdr_t *) fp_DataInfo->pu8Data;

    if (IS_REQUEST(*pHdr))
    {
        for (i = 0; i < COUNT_OF(fs_aFuncArray); i++)
        {
            if (fs_aFuncArray[i].funcId == pHdr->funcId)
            {
                if (fs_aFuncArray[i].pfFunc != NULL)
                {
                    bIsFuncSupported = true;
                    fs_aFuncArray[i].pfFunc(fp_DataInfo);
                }

                break;
            }
        }

        if (!bIsFuncSupported)
            (void) ProtocolSendErrorResp(fp_DataInfo, (uint8_t) ESSA_FP_ERRCODE_FUNC_NOT_SUPPORTED);
    }

    return bIsFuncSupported;
}

static void fs_getHealthInfoReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpgetHealthInfoProtocolRequestData_t *fullrequest = (SharpgetHealthInfoProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpgetHealthInfoProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_getHealthInfoRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_getHealthInfoRequestHandler(&requestCtx);
    }
}

static void fs_getSHIPInfoReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpgetSHIPInfoProtocolRequestData_t *fullrequest = (SharpgetSHIPInfoProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSHIPInfoProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_getSHIPInfoRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_getSHIPInfoRequestHandler(&requestCtx);
    }
}

static void fs_setDetectorPowerReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpsetDetectorPowerProtocolRequestData_t *fullrequest = (SharpsetDetectorPowerProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SharpsetDetectorPowerRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpsetDetectorPowerProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SharpsetDetectorPowerRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_setDetectorPowerRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_setDetectorPowerRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_setSharpTimeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpsetSharpTimeProtocolRequestData_t *fullrequest = (SharpsetSharpTimeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SharpsetSharpTimeRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpTimeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SharpsetSharpTimeRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_setSharpTimeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_setSharpTimeRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_setSharpDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpsetSharpDateProtocolRequestData_t *fullrequest = (SharpsetSharpDateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SharpsetSharpDateRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpDateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SharpsetSharpDateRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_setSharpDateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_setSharpDateRequestHandler(&requestCtx,
                                        requestPayload);
    }
}

static void fs_getSharpTimeDateReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpgetSharpTimeDateProtocolRequestData_t *fullrequest = (SharpgetSharpTimeDateProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSharpTimeDateProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_getSharpTimeDateRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_getSharpTimeDateRequestHandler(&requestCtx);
    }
}

static void fs_getSharpModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpgetSharpModeProtocolRequestData_t *fullrequest = (SharpgetSharpModeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSharpModeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    // no out-arguments specified for response - simple acknowledge call
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_getSharpModeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_getSharpModeRequestHandler(&requestCtx);
    }
}

static void fs_setSharpModeReq(ESSA_Stack_DataDispatchInfo_t *fp_DataInfo)
{
    SharpsetSharpModeProtocolRequestData_t *fullrequest = (SharpsetSharpModeProtocolRequestData_t *) fp_DataInfo->pu8Data;
    SharpsetSharpModeRequestData_t *requestPayload = NULL;
    ReqContext_t requestCtx;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpModeProtocolRequestData_t);

    if ((fullrequest == NULL) || (pSrvApiHnd == NULL) || (fp_DataInfo->u16DataSize != sizeof(*fullrequest)))
    {
        return;
    }
#ifndef BIG_ENDIAN_PLATFORM
    requestPayload = (SharpsetSharpModeRequestData_t *) &fullrequest->data;
#else   // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Deserialize response fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    if (pSrvApiHnd->Sharp_setSharpModeRequestHandler != NULL)
    {
        requestCtx.nInterfaceNumber = fp_DataInfo->pMACContext->nInterfaceNumber;
        requestCtx.netType = fp_DataInfo->pMACContext->netType;
        requestCtx.nAddr = fp_DataInfo->pMACContext->nSourceAddr;
        requestCtx.seqId = fullrequest->hdr.seqId;

        pSrvApiHnd->Sharp_setSharpModeRequestHandler(&requestCtx,
                                        requestPayload);
    }
}


/**********************************************************************
 *
 *  Public methods implementation
 *
 **********************************************************************/
void Sharp_registerServerApi(Sharp_ServerApi_t *pSrvApiHandlers)
{
    pSrvApiHnd = pSrvApiHandlers;
}

ESSA_pStack_FunctionProtocolInfo_t Sharp_getServerProtocolDescriptor(void)
{
    return (ESSA_pStack_FunctionProtocolInfo_t) &FP_SharpProtocolServerInfo;
}

ESSATMAC_ErrCodes Sharp_getHealthInfoResp(
                RespContext_t* ctx,
                const SHARP_sdate_t * const sDate,
                const SHARP_stime_t * const sTime,
                const SHARP_sfaultstateSharp_t * const sFaults,
                const SHARP_sDetectorTemps_t * const sTemperatures,
                const SHARP_sDetectorVoltages_t * const sVoltages,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpgetHealthInfoProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpgetHealthInfoProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpgetHealthInfoProtocolResponseData_t);

    if ((ctx != NULL) && (sDate != NULL) && (sTime != NULL) && (sFaults != NULL) && (sTemperatures != NULL) && (sVoltages != NULL) && (sDetectorStatus != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_GETHEALTHINFO_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sDate != NULL)
        {
            responseParams.data.sDate = *(sDate);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDate,
                          0U,
                          sizeof(responseParams.data.sDate));
        }
        if (sTime != NULL)
        {
            responseParams.data.sTime = *(sTime);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTime,
                          0U,
                          sizeof(responseParams.data.sTime));
        }
        if (sFaults != NULL)
        {
            responseParams.data.sFaults = *(sFaults);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sFaults,
                          0U,
                          sizeof(responseParams.data.sFaults));
        }
        if (sTemperatures != NULL)
        {
            responseParams.data.sTemperatures = *(sTemperatures);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTemperatures,
                          0U,
                          sizeof(responseParams.data.sTemperatures));
        }
        if (sVoltages != NULL)
        {
            responseParams.data.sVoltages = *(sVoltages);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sVoltages,
                          0U,
                          sizeof(responseParams.data.sVoltages));
        }
        if (sDetectorStatus != NULL)
        {
            responseParams.data.sDetectorStatus = *(sDetectorStatus);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDetectorStatus,
                          0U,
                          sizeof(responseParams.data.sDetectorStatus));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpgetHealthInfoProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_getSHIPInfoResp(
                RespContext_t* ctx,
                const SHARP_sSHIPVersion_t * const sVersioning,
                const SHARP_sFPGAVersion_t * const sFpga_versioning,
                const SHARP_sSHIPStorage_t * const sShipStorage,
                const SHARP_sSHIPPower_t * const sShipPower
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpgetSHIPInfoProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpgetSHIPInfoProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSHIPInfoProtocolResponseData_t);

    if ((ctx != NULL) && (sVersioning != NULL) && (sFpga_versioning != NULL) && (sShipStorage != NULL) && (sShipPower != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_GETSHIPINFO_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sVersioning != NULL)
        {
            responseParams.data.sVersioning = *(sVersioning);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sVersioning,
                          0U,
                          sizeof(responseParams.data.sVersioning));
        }
        if (sFpga_versioning != NULL)
        {
            responseParams.data.sFpga_versioning = *(sFpga_versioning);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sFpga_versioning,
                          0U,
                          sizeof(responseParams.data.sFpga_versioning));
        }
        if (sShipStorage != NULL)
        {
            responseParams.data.sShipStorage = *(sShipStorage);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sShipStorage,
                          0U,
                          sizeof(responseParams.data.sShipStorage));
        }
        if (sShipPower != NULL)
        {
            responseParams.data.sShipPower = *(sShipPower);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sShipPower,
                          0U,
                          sizeof(responseParams.data.sShipPower));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpgetSHIPInfoProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_setDetectorPowerResp(
                RespContext_t* ctx,
                const SHARP_DetectorPower_t eOpResult,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpsetDetectorPowerProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpsetDetectorPowerProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpsetDetectorPowerProtocolResponseData_t);

    if ((ctx != NULL) && (sDetectorStatus != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_SETDETECTORPOWER_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eOpResult = eOpResult;
        if (sDetectorStatus != NULL)
        {
            responseParams.data.sDetectorStatus = *(sDetectorStatus);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDetectorStatus,
                          0U,
                          sizeof(responseParams.data.sDetectorStatus));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpsetDetectorPowerProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_setSharpTimeResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpsetSharpTimeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpsetSharpTimeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpTimeProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_SETSHARPTIME_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpsetSharpTimeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_setSharpDateResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eExecutionSuccess
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpsetSharpDateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpsetSharpDateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpDateProtocolResponseData_t);

    if (ctx != NULL)
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_SETSHARPDATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eExecutionSuccess = eExecutionSuccess;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpsetSharpDateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_getSharpTimeDateResp(
                RespContext_t* ctx,
                const SHARP_stime_t * const sTime,
                const SHARP_sdate_t * const sDate
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpgetSharpTimeDateProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpgetSharpTimeDateProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSharpTimeDateProtocolResponseData_t);

    if ((ctx != NULL) && (sTime != NULL) && (sDate != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_GETSHARPTIMEDATE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sTime != NULL)
        {
            responseParams.data.sTime = *(sTime);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sTime,
                          0U,
                          sizeof(responseParams.data.sTime));
        }
        if (sDate != NULL)
        {
            responseParams.data.sDate = *(sDate);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sDate,
                          0U,
                          sizeof(responseParams.data.sDate));
        }
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpgetSharpTimeDateProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_getSharpModeResp(
                RespContext_t* ctx,
                const SHARP_sSHARPParameters_t * const sParameters,
                const SHARP_eSHARPModes_t eMode
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpgetSharpModeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpgetSharpModeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpgetSharpModeProtocolResponseData_t);

    if ((ctx != NULL) && (sParameters != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_GETSHARPMODE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        if (sParameters != NULL)
        {
            responseParams.data.sParameters = *(sParameters);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sParameters,
                          0U,
                          sizeof(responseParams.data.sParameters));
        }
        responseParams.data.eMode = eMode;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpgetSharpModeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}

ESSATMAC_ErrCodes Sharp_setSharpModeResp(
                RespContext_t* ctx,
                const SHARP_eCommandExecutionReturn_t eOpResult,
                const SHARP_sSHARPParameters_t * const sParameters,
                const SHARP_eSHARPModes_t eMode
)
{
#ifndef BIG_ENDIAN_PLATFORM
    SharpsetSharpModeProtocolResponseData_t responseParams;
#else  // #ifndef BIG_ENDIAN_PLATFORM
    uint8_t responseParams[sizeof(SharpsetSharpModeProtocolResponseData_t)] = { 0 };
#endif  // #ifndef BIG_ENDIAN_PLATFORM

    ESSATMAC_ErrCodes sendResult = ESSATMAC_EC_NULL;

    STATIC_ASSERT_SIZE_CHECK(SharpsetSharpModeProtocolResponseData_t);

    if ((ctx != NULL) && (sParameters != NULL))
    {
#ifndef BIG_ENDIAN_PLATFORM
        // fill message header
        // RS485 wire protocol also uses LE byte order -> serialization of params is not needed
        responseParams.hdr.protoId = ES_SAT_FUNC_PROTOCOL_ID_SHARP;
        responseParams.hdr.funcId  = SHARP_SETSHARPMODE_FUNCRESP_ID;
        responseParams.hdr.seqId   = ctx->seqId;
        responseParams.hdr.errCode = ESSA_FP_ERRCODE_NOERROR;
        SET_RESPONSE(responseParams.hdr);

        // fill message data
        responseParams.data.eOpResult = eOpResult;
        if (sParameters != NULL)
        {
            responseParams.data.sParameters = *(sParameters);
        }
        else
        {
            (void) memset((void *) &responseParams.data.sParameters,
                          0U,
                          sizeof(responseParams.data.sParameters));
        }
        responseParams.data.eMode = eMode;
#else // #ifndef BIG_ENDIAN_PLATFORM
    // TBD: Serialize request fields
#endif  // #ifndef BIG_ENDIAN_PLATFORM

        sendResult = ESSA_Stack_SendFrameEx((ESSASNetInterface) ctx->nInterfaceNumber,
                                            ctx->netType,
                                            ctx->nAddr,
                                            ES_SAT_MAC_PROTOCOL_ID_FP_LAYER,
#ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) &responseParams,
#else // #ifndef BIG_ENDIAN_PLATFORM
                                            (uint8_t *) responseParams,
#endif // #ifndef BIG_ENDIAN_PLATFORM
                                            sizeof(SharpsetSharpModeProtocolResponseData_t),
                                            STACK_SENDFRAME_DEFAULT_PRIO,
                                            (ESSATMAC_DrvResult_Cbk_t) NULL,
                                            (uint32_t *) NULL);
    }

    return sendResult;
}


