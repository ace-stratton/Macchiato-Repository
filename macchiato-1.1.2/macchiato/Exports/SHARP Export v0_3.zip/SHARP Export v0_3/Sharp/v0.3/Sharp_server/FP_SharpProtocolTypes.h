/*!
********************************************************************************************
* @file FP_SharpProtocolTypes.h
* @brief Protocol public type declarations
********************************************************************************************
* @version           interface Sharp v0.3
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SHARPPROTOCOLTYPES_H__
#define __FP_SHARPPROTOCOLTYPES_H__

#include <stddef.h>
#include "FP_common/FP_BaseProtocolTypes.h"
#include "FP_common/FP_Helpers.h"

/**********************************************************************
 *
 *  Shared defines
 *
 **********************************************************************/
#define ES_SAT_FUNC_PROTOCOL_ID_SHARP ((uint16_t) (0x00000069))

#define SHARP_GETHEALTHINFO_FUNC_ID ((funcIdType_t) 0x00000001)
#define SHARP_GETSHIPINFO_FUNC_ID ((funcIdType_t) 0x00000002)
#define SHARP_SETDETECTORPOWER_FUNC_ID ((funcIdType_t) 0x00000003)
#define SHARP_SETSHARPTIME_FUNC_ID ((funcIdType_t) 0x00000004)
#define SHARP_SETSHARPDATE_FUNC_ID ((funcIdType_t) 0x00000005)
#define SHARP_GETSHARPTIMEDATE_FUNC_ID ((funcIdType_t) 0x00000006)
#define SHARP_GETSHARPMODE_FUNC_ID ((funcIdType_t) 0x00000007)
#define SHARP_SETSHARPMODE_FUNC_ID ((funcIdType_t) 0x00000008)
#define SHARP_GETHEALTHINFO_FUNCRESP_ID ((funcIdType_t) 0x00000001)
#define SHARP_GETSHIPINFO_FUNCRESP_ID ((funcIdType_t) 0x00000002)
#define SHARP_SETDETECTORPOWER_FUNCRESP_ID ((funcIdType_t) 0x00000003)
#define SHARP_SETSHARPTIME_FUNCRESP_ID ((funcIdType_t) 0x00000004)
#define SHARP_SETSHARPDATE_FUNCRESP_ID ((funcIdType_t) 0x00000005)
#define SHARP_GETSHARPTIMEDATE_FUNCRESP_ID ((funcIdType_t) 0x00000006)
#define SHARP_GETSHARPMODE_FUNCRESP_ID ((funcIdType_t) 0x00000007)
#define SHARP_SETSHARPMODE_FUNCRESP_ID ((funcIdType_t) 0x00000008)

/**********************************************************************
 *
 *  Type definitions
 *
 **********************************************************************/
/*
    DetectorStatus (ON, OFF, ERROR)
*/
#define SHARP_DETECTORSTATUS_ON ((uint8_t) 0)
#define SHARP_DETECTORSTATUS_OFF ((uint8_t) 1)
#define SHARP_DETECTORSTATUS_ERROR ((uint8_t) 2)
#define SHARP_DETECTORSTATUS_MAX_CNT  ((uint8_t) 3)
typedef uint8_t SHARP_DetectorStatus_t;

/*
    DetectorStatus (ON, OFF)
*/
#define SHARP_DETECTORPOWER_ON ((uint8_t) 0)
#define SHARP_DETECTORPOWER_OFF ((uint8_t) 1)
#define SHARP_DETECTORPOWER_MAX_CNT  ((uint8_t) 2)
typedef uint8_t SHARP_DetectorPower_t;

/*
    Date
*/
typedef struct {
    uint16_t u16Year;
    uint8_t u8Mon;
    uint8_t u8Day;
} PACKED_STRUCT SHARP_sdate_t;

/*
    Time
*/
typedef struct {
    uint8_t u8Hour;
    uint8_t u8Min;
    uint8_t u8Sec;
    uint16_t u16Ms;
    uint16_t u16Us;
} PACKED_STRUCT SHARP_stime_t;

/*
    SHARP Fault Flag
*/
typedef struct {
    bool bFaultflag;
    uint8_t u8Faultcount;
} PACKED_STRUCT SHARP_sfaultstateSharp_t;

/*
    SHARP Detector Temperatures [C]
*/
typedef struct {
    uint32_t u32Temp1;
    uint32_t u32Temp2;
    uint32_t u32Temp3;
    uint32_t u32Temp4;
    uint32_t u32Temp5;
    uint32_t u32Temp6;
    uint32_t u32Temp7;
    uint32_t u32Temp8;
} PACKED_STRUCT SHARP_sDetectorTemps_t;

/*
    SHARP Detector Voltages [V]
*/
typedef struct {
    uint32_t u32Volt1;
    uint32_t u32Volt2;
    uint32_t u32Volt3;
    uint32_t u32Volt4;
    uint32_t u32Volt5;
    uint32_t u32Volt6;
    uint32_t u32Volt7;
    uint32_t u32Volt8;
} PACKED_STRUCT SHARP_sDetectorVoltages_t;

/*
    SHARP Detector Status
*/
typedef struct {
    SHARP_DetectorStatus_t eStatus1;
    SHARP_DetectorStatus_t eStatus2;
    SHARP_DetectorStatus_t eStatus3;
    SHARP_DetectorStatus_t eStatus4;
    SHARP_DetectorStatus_t eStatus5;
    SHARP_DetectorStatus_t eStatus6;
    SHARP_DetectorStatus_t eStatus7;
    SHARP_DetectorStatus_t eStatus8;
} PACKED_STRUCT SHARP_sDetectorStatus_t;

/*
    SHIP Firmware and Software Version
*/
typedef struct {
    uint16_t u16FirmwareMajor;
    uint16_t u16FirmwareMinor;
    uint16_t u16SoftwareMajor;
    uint16_t u16SoftwareMinor;
} PACKED_STRUCT SHARP_sSHIPVersion_t;

/*
    SHIP Firmware and Software Version
*/
typedef struct {
    uint16_t u16FpgafirmwareMajor;
    uint16_t u16FpgafirmwareMinor;
} PACKED_STRUCT SHARP_sFPGAVersion_t;

/*
    SHIP Storage
*/
typedef struct {
    uint32_t u32UsedShipSpace;
    uint32_t u32FreeShipSpace;
} PACKED_STRUCT SHARP_sSHIPStorage_t;

/*
    SHIP Power
*/
typedef struct {
    uint32_t u32VoltageShip;
    uint32_t u32CurrentShip;
} PACKED_STRUCT SHARP_sSHIPPower_t;

/*
    Shows status of sent command
*/
#define SHARP_ECOMMANDEXECUTIONRETURN_SUCCESS ((uint8_t) 0)
#define SHARP_ECOMMANDEXECUTIONRETURN_FAIL ((uint8_t) 1)
#define SHARP_ECOMMANDEXECUTIONRETURN_MAX_CNT  ((uint8_t) 2)
typedef uint8_t SHARP_eCommandExecutionReturn_t;

/*
    Possible SHARP Modes
*/
#define SHARP_ESHARPMODES_SHARP_IDLE_MODE ((uint8_t) 0)
#define SHARP_ESHARPMODES_SHARP_Low_Power_Mode ((uint8_t) 1)
#define SHARP_ESHARPMODES_SHARP_Engineering_Mode ((uint8_t) 2)
#define SHARP_ESHARPMODES_SHARP_Nominal_Science_Mode ((uint8_t) 3)
#define SHARP_ESHARPMODES_SHARP_Fast_Readout_Science_Mode ((uint8_t) 4)
#define SHARP_ESHARPMODES_SHARP_Safe_Mode ((uint8_t) 5)
#define SHARP_ESHARPMODES_SHARP_State_Machine_Off ((uint8_t) 6)
#define SHARP_ESHARPMODES_SHARP_State_Machine_On ((uint8_t) 7)
#define SHARP_ESHARPMODES_MAX_CNT  ((uint8_t) 8)
typedef uint8_t SHARP_eSHARPModes_t;

/*
    Command Parameters
*/
typedef struct {
    uint32_t u32Parameter1;
    uint32_t u32Parameter2;
    uint32_t u32Parameter3;
} PACKED_STRUCT SHARP_sSHARPParameters_t;


typedef struct {
    uint32_t u32DetectorID;
    SHARP_DetectorPower_t eOnOff;
} PACKED_STRUCT SharpsetDetectorPowerRequestData_t;

typedef struct {
    bool bGNSS;
    SHARP_stime_t sTime;
} PACKED_STRUCT SharpsetSharpTimeRequestData_t;

typedef struct {
    bool bGNSS;
    SHARP_sdate_t sDate;
} PACKED_STRUCT SharpsetSharpDateRequestData_t;

typedef struct {
    SHARP_sSHARPParameters_t sParameters;
    SHARP_eSHARPModes_t eMode;
} PACKED_STRUCT SharpsetSharpModeRequestData_t;


typedef struct {
    SHARP_sdate_t sDate;
    SHARP_stime_t sTime;
    SHARP_sfaultstateSharp_t sFaults;
    SHARP_sDetectorTemps_t sTemperatures;
    SHARP_sDetectorVoltages_t sVoltages;
    SHARP_sDetectorStatus_t sDetectorStatus;
} PACKED_STRUCT SharpgetHealthInfoResponseData_t;

typedef struct {
    SHARP_sSHIPVersion_t sVersioning;
    SHARP_sFPGAVersion_t sFpga_versioning;
    SHARP_sSHIPStorage_t sShipStorage;
    SHARP_sSHIPPower_t sShipPower;
} PACKED_STRUCT SharpgetSHIPInfoResponseData_t;

typedef struct {
    SHARP_DetectorPower_t eOpResult;
    SHARP_sDetectorStatus_t sDetectorStatus;
} PACKED_STRUCT SharpsetDetectorPowerResponseData_t;

typedef struct {
    SHARP_eCommandExecutionReturn_t eExecutionSuccess;
} PACKED_STRUCT SharpsetSharpTimeResponseData_t;

typedef struct {
    SHARP_eCommandExecutionReturn_t eExecutionSuccess;
} PACKED_STRUCT SharpsetSharpDateResponseData_t;

typedef struct {
    SHARP_stime_t sTime;
    SHARP_sdate_t sDate;
} PACKED_STRUCT SharpgetSharpTimeDateResponseData_t;

typedef struct {
    SHARP_sSHARPParameters_t sParameters;
    SHARP_eSHARPModes_t eMode;
} PACKED_STRUCT SharpgetSharpModeResponseData_t;

typedef struct {
    SHARP_eCommandExecutionReturn_t eOpResult;
    SHARP_sSHARPParameters_t sParameters;
    SHARP_eSHARPModes_t eMode;
} PACKED_STRUCT SharpsetSharpModeResponseData_t;


#endif  // #ifndef __FP_SHARPPROTOCOLTYPES_H__

