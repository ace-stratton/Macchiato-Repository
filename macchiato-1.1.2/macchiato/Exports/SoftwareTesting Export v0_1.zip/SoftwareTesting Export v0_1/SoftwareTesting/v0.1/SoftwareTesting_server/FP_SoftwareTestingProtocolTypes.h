/*!
********************************************************************************************
* @file FP_SoftwareTestingProtocolTypes.h
* @brief Protocol public type declarations
********************************************************************************************
* @version           interface SoftwareTesting v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SOFTWARETESTINGPROTOCOLTYPES_H__
#define __FP_SOFTWARETESTINGPROTOCOLTYPES_H__

#include <stddef.h>
#include "FP_common/FP_BaseProtocolTypes.h"
#include "FP_common/FP_Helpers.h"

/**********************************************************************
 *
 *  Shared defines
 *
 **********************************************************************/
#define ES_SAT_FUNC_PROTOCOL_ID_SOFTWARETESTING ((uint16_t) (0x0000006D))

#define SOFTWARETESTING_OM1_OPMODERESET_FUNC_ID ((funcIdType_t) 0x00000001)
#define SOFTWARETESTING_OM2_COMMANDFLOOD_FUNC_ID ((funcIdType_t) 0x00000002)
#define SOFTWARETESTING_C1_COMMANDVERIFICATION_FUNC_ID ((funcIdType_t) 0x00000003)
#define SOFTWARETESTING_C2_INSTRUMENTVERIFICATION_FUNC_ID ((funcIdType_t) 0x00000004)
#define SOFTWARETESTING_C4_COMMANDEXECUTIONRELATIVETIMING_FUNC_ID ((funcIdType_t) 0x00000005)
#define SOFTWARETESTING_C5_COMMANDEXECUTIONABSOLUTETIMING_FUNC_ID ((funcIdType_t) 0x00000006)
#define SOFTWARETESTING_GETCOMMANDEXECUTIONTIMING_FUNC_ID ((funcIdType_t) 0x00000007)
#define SOFTWARETESTING_C6_GETTIME_FUNC_ID ((funcIdType_t) 0x00000008)
#define SOFTWARETESTING_OM1_OPMODERESET_FUNCRESP_ID ((funcIdType_t) 0x00000001)
#define SOFTWARETESTING_OM2_COMMANDFLOOD_FUNCRESP_ID ((funcIdType_t) 0x00000002)
#define SOFTWARETESTING_C1_COMMANDVERIFICATION_FUNCRESP_ID ((funcIdType_t) 0x00000003)
#define SOFTWARETESTING_C2_INSTRUMENTVERIFICATION_FUNCRESP_ID ((funcIdType_t) 0x00000004)
#define SOFTWARETESTING_C4_COMMANDEXECUTIONRELATIVETIMING_FUNCRESP_ID ((funcIdType_t) 0x00000005)
#define SOFTWARETESTING_C5_COMMANDEXECUTIONABSOLUTETIMING_FUNCRESP_ID ((funcIdType_t) 0x00000006)
#define SOFTWARETESTING_GETCOMMANDEXECUTIONTIMING_FUNCRESP_ID ((funcIdType_t) 0x00000007)
#define SOFTWARETESTING_C6_GETTIME_FUNCRESP_ID ((funcIdType_t) 0x00000008)

/**********************************************************************
 *
 *  Type definitions
 *
 **********************************************************************/
/*
    Reset Modes
*/
#define SOFTWARETESTING_ERESETMODES_RESET1 ((uint8_t) 0)
#define SOFTWARETESTING_ERESETMODES_RESET2 ((uint8_t) 1)
#define SOFTWARETESTING_ERESETMODES_RESET3 ((uint8_t) 2)
#define SOFTWARETESTING_ERESETMODES_RESET4 ((uint8_t) 3)
#define SOFTWARETESTING_ERESETMODES_MAX_CNT  ((uint8_t) 4)
typedef uint8_t SOFTWARETESTING_eResetModes_t;

/*
    OperationalModes (SAFE, HELL, ERROR)
*/
#define SOFTWARETESTING_EOPMODES_SAFE ((uint8_t) 0)
#define SOFTWARETESTING_EOPMODES_HELL ((uint8_t) 1)
#define SOFTWARETESTING_EOPMODES_ERROR ((uint8_t) 2)
#define SOFTWARETESTING_EOPMODES_MAX_CNT  ((uint8_t) 3)
typedef uint8_t SOFTWARETESTING_eOpModes_t;

/*
    Command recieve counts
*/
typedef struct {
    uint32_t u32CommandCount;
} PACKED_STRUCT SOFTWARETESTING_sCommandCount_t;

/*
    Command Verification Modes
*/
#define SOFTWARETESTING_EVERIFICATIONMODES_NOMINAL ((uint8_t) 0)
#define SOFTWARETESTING_EVERIFICATIONMODES_ECHO ((uint8_t) 1)
#define SOFTWARETESTING_EVERIFICATIONMODES_COUNT ((uint8_t) 2)
#define SOFTWARETESTING_EVERIFICATIONMODES_ECHO_AND_COUNT ((uint8_t) 3)
#define SOFTWARETESTING_EVERIFICATIONMODES_MAX_CNT  ((uint8_t) 4)
typedef uint8_t SOFTWARETESTING_eVerificationModes_t;

/*
    Echo Command Value
*/
typedef struct {
    uint32_t u32EchoValue;
} PACKED_STRUCT SOFTWARETESTING_sEchoValue_t;

/*
    Instrument Selection
*/
#define SOFTWARETESTING_EINSTRUMENTOPT_SHARP ((uint8_t) 0)
#define SOFTWARETESTING_EINSTRUMENTOPT_MeDDEA ((uint8_t) 1)
#define SOFTWARETESTING_EINSTRUMENTOPT_MAX_CNT  ((uint8_t) 2)
typedef uint8_t SOFTWARETESTING_eInstrumentOpt_t;

/*
    Instrument Power Selection
*/
#define SOFTWARETESTING_EINSTRUMENTPOWER_NO_CHANGE ((uint8_t) 0)
#define SOFTWARETESTING_EINSTRUMENTPOWER_POWER_ON ((uint8_t) 1)
#define SOFTWARETESTING_EINSTRUMENTPOWER_POWER_OFF ((uint8_t) 2)
#define SOFTWARETESTING_EINSTRUMENTPOWER_MAX_CNT  ((uint8_t) 3)
typedef uint8_t SOFTWARETESTING_eInstrumentPower_t;

/*
    Shows status of sent command
*/
#define SOFTWARETESTING_ECOMMANDEXECUTIONRETURN_SUCCESS ((uint8_t) 0)
#define SOFTWARETESTING_ECOMMANDEXECUTIONRETURN_FAIL ((uint8_t) 1)
#define SOFTWARETESTING_ECOMMANDEXECUTIONRETURN_MAX_CNT  ((uint8_t) 2)
typedef uint8_t SOFTWARETESTING_eCommandExecutionReturn_t;

/*
    Date
*/
typedef struct {
    uint16_t u16Year;
    uint8_t u8Mon;
    uint8_t u8Day;
} PACKED_STRUCT SOFTWARETESTING_sdate_t;

/*
    Time
*/
typedef struct {
    uint8_t u8Hour;
    uint8_t u8Min;
    uint8_t u8Sec;
    uint16_t u16Ms;
    uint16_t u16Us;
} PACKED_STRUCT SOFTWARETESTING_stime_t;


typedef struct {
    SOFTWARETESTING_eResetModes_t eResetMode;
} PACKED_STRUCT SoftwareTestingOM1_OpModeResetRequestData_t;

typedef struct {
    uint32_t u32CommandSendSpeed;
} PACKED_STRUCT SoftwareTestingOM2_CommandFloodRequestData_t;

typedef struct {
    SOFTWARETESTING_eVerificationModes_t eVerificationMode;
    uint32_t u32NumSendCommands;
    SOFTWARETESTING_sEchoValue_t sEchoValueSend;
} PACKED_STRUCT SoftwareTestingC1_CommandVerificationRequestData_t;

typedef struct {
    SOFTWARETESTING_eInstrumentOpt_t eInstrumentSelection;
    SOFTWARETESTING_eInstrumentPower_t ePowerSelection;
    SOFTWARETESTING_sEchoValue_t sEchoValueSend;
} PACKED_STRUCT SoftwareTestingC2_InstrumentVerificationRequestData_t;

typedef struct {
    uint32_t u32TimeDelay;
    SOFTWARETESTING_sEchoValue_t sEchoValueSend;
} PACKED_STRUCT SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t;

typedef struct {
    SOFTWARETESTING_sdate_t sDateSet;
    SOFTWARETESTING_stime_t sTimeSet;
    SOFTWARETESTING_sEchoValue_t sEchoValueSend;
} PACKED_STRUCT SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t;


typedef struct {
    SOFTWARETESTING_eOpModes_t eOpMode;
} PACKED_STRUCT SoftwareTestingOM1_OpModeResetResponseData_t;

typedef struct {
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
} PACKED_STRUCT SoftwareTestingOM2_CommandFloodResponseData_t;

typedef struct {
    SOFTWARETESTING_eVerificationModes_t eVerificationModeReturn;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;
} PACKED_STRUCT SoftwareTestingC1_CommandVerificationResponseData_t;

typedef struct {
    SOFTWARETESTING_eInstrumentOpt_t eInstrumentSelectionReturn;
    SOFTWARETESTING_eInstrumentPower_t ePowerSelectionReturn;
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;
} PACKED_STRUCT SoftwareTestingC2_InstrumentVerificationResponseData_t;

typedef struct {
    SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn;
} PACKED_STRUCT SoftwareTestingC4_CommandExecutionRelativeTimingResponseData_t;

typedef struct {
    SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn;
} PACKED_STRUCT SoftwareTestingC5_CommandExecutionAbsoluteTimingResponseData_t;

typedef struct {
    SOFTWARETESTING_sCommandCount_t sNumOfCommandsRecieved;
    SOFTWARETESTING_sEchoValue_t sEchoReturn;
    SOFTWARETESTING_sdate_t sDateCommandReturn;
    SOFTWARETESTING_stime_t sTimeCommandReturn;
} PACKED_STRUCT SoftwareTestinggetCommandExecutionTimingResponseData_t;

typedef struct {
    uint32_t u32UpTime;
    SOFTWARETESTING_sdate_t sDate;
    SOFTWARETESTING_stime_t sTime;
} PACKED_STRUCT SoftwareTestingC6_getTimeResponseData_t;


#endif  // #ifndef __FP_SOFTWARETESTINGPROTOCOLTYPES_H__

