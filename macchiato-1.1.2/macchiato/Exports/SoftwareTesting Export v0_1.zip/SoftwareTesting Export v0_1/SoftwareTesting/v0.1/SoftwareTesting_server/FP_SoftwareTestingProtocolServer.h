/*!
********************************************************************************************
* @file FP_SoftwareTestingProtocolServer.h
* @brief ESSA Stack server-side public API declaration
********************************************************************************************
* @version           interface SoftwareTesting v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SOFTWARETESTINGPROTOCOLSERVER_H__
#define __FP_SOFTWARETESTINGPROTOCOLSERVER_H__

#include "FP_SoftwareTestingProtocolTypes.h"

typedef void (*pfSoftwareTesting_OM1_OpModeResetRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingOM1_OpModeResetRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_OM2_CommandFloodRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingOM2_CommandFloodRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_C1_CommandVerificationRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingC1_CommandVerificationRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_C2_InstrumentVerificationRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingC2_InstrumentVerificationRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingC4_CommandExecutionRelativeTimingRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler_t)(ReqContext_t *ctx, SoftwareTestingC5_CommandExecutionAbsoluteTimingRequestData_t *pRequestData);
typedef void (*pfSoftwareTesting_getCommandExecutionTimingRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSoftwareTesting_C6_getTimeRequestHandler_t)(ReqContext_t *ctx);

typedef struct {
    pfSoftwareTesting_OM1_OpModeResetRequestHandler_t SoftwareTesting_OM1_OpModeResetRequestHandler;
    pfSoftwareTesting_OM2_CommandFloodRequestHandler_t SoftwareTesting_OM2_CommandFloodRequestHandler;
    pfSoftwareTesting_C1_CommandVerificationRequestHandler_t SoftwareTesting_C1_CommandVerificationRequestHandler;
    pfSoftwareTesting_C2_InstrumentVerificationRequestHandler_t SoftwareTesting_C2_InstrumentVerificationRequestHandler;
    pfSoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler_t SoftwareTesting_C4_CommandExecutionRelativeTimingRequestHandler;
    pfSoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler_t SoftwareTesting_C5_CommandExecutionAbsoluteTimingRequestHandler;
    pfSoftwareTesting_getCommandExecutionTimingRequestHandler_t SoftwareTesting_getCommandExecutionTimingRequestHandler;
    pfSoftwareTesting_C6_getTimeRequestHandler_t SoftwareTesting_C6_getTimeRequestHandler;
} SoftwareTesting_ServerApi_t;

/**********************************************************************
 *
 *  Server protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_SoftwareTestingProtocolServerInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void SoftwareTesting_registerServerApi(SoftwareTesting_ServerApi_t *pSrvApiHandlers);

// @deprecated - will be removed in the future - use FP_SoftwareTestingProtocolServerInfo directly
ESSA_pStack_FunctionProtocolInfo_t SoftwareTesting_getServerProtocolDescriptor(void);

ESSATMAC_ErrCodes SoftwareTesting_OM1_OpModeResetResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eOpModes_t eOpMode
);

ESSATMAC_ErrCodes SoftwareTesting_OM2_CommandFloodResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved
);

ESSATMAC_ErrCodes SoftwareTesting_C1_CommandVerificationResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eVerificationModes_t eVerificationModeReturn,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn
);

ESSATMAC_ErrCodes SoftwareTesting_C2_InstrumentVerificationResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eInstrumentOpt_t eInstrumentSelectionReturn,
                const SOFTWARETESTING_eInstrumentPower_t ePowerSelectionReturn,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn
);

ESSATMAC_ErrCodes SoftwareTesting_C4_CommandExecutionRelativeTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn
);

ESSATMAC_ErrCodes SoftwareTesting_C5_CommandExecutionAbsoluteTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_eCommandExecutionReturn_t eCommandReturn
);

ESSATMAC_ErrCodes SoftwareTesting_getCommandExecutionTimingResp(
                RespContext_t* ctx,
                const SOFTWARETESTING_sCommandCount_t * const sNumOfCommandsRecieved,
                const SOFTWARETESTING_sEchoValue_t * const sEchoReturn,
                const SOFTWARETESTING_sdate_t * const sDateCommandReturn,
                const SOFTWARETESTING_stime_t * const sTimeCommandReturn
);

ESSATMAC_ErrCodes SoftwareTesting_C6_getTimeResp(
                RespContext_t* ctx,
                const uint32_t u32UpTime,
                const SOFTWARETESTING_sdate_t * const sDate,
                const SOFTWARETESTING_stime_t * const sTime
);


#endif  // #ifndef __FP_SOFTWARETESTINGPROTOCOLSERVER_H__
