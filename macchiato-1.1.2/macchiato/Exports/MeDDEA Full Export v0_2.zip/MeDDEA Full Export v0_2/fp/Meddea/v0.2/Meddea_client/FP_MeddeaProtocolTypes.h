/*!
********************************************************************************************
* @file FP_MeddeaProtocolTypes.h
* @brief Protocol public type declarations
********************************************************************************************
* @version           interface Meddea v0.2
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_MEDDEAPROTOCOLTYPES_H__
#define __FP_MEDDEAPROTOCOLTYPES_H__

#include <stddef.h>
#include "FP_common/FP_BaseProtocolTypes.h"
#include "FP_common/FP_Helpers.h"

/**********************************************************************
 *
 *  Shared defines
 *
 **********************************************************************/
#define ES_SAT_FUNC_PROTOCOL_ID_MEDDEA ((uint16_t) (0x0000006A))

#define MEDDEA_GETMEDDEAMODE_FUNC_ID ((funcIdType_t) 0x00000001)
#define MEDDEA_SETMEDDEAMODE_FUNC_ID ((funcIdType_t) 0x00000002)
#define MEDDEA_WRITEMEDDEA_FUNC_ID ((funcIdType_t) 0x00000003)
#define MEDDEA_READMEDDEA_FUNC_ID ((funcIdType_t) 0x00000004)
#define MEDDEA_GETMEDDEAMODE_FUNCRESP_ID ((funcIdType_t) 0x00000001)
#define MEDDEA_SETMEDDEAMODE_FUNCRESP_ID ((funcIdType_t) 0x00000002)
#define MEDDEA_WRITEMEDDEA_FUNCRESP_ID ((funcIdType_t) 0x00000003)
#define MEDDEA_READMEDDEA_FUNCRESP_ID ((funcIdType_t) 0x00000004)

/**********************************************************************
 *
 *  Type definitions
 *
 **********************************************************************/
/*
    Shows status of sent command
*/
#define MEDDEA_ECOMMANDEXECUTIONRETURN_SUCCESS ((uint8_t) 0)
#define MEDDEA_ECOMMANDEXECUTIONRETURN_FAIL ((uint8_t) 1)
#define MEDDEA_ECOMMANDEXECUTIONRETURN_MAX_CNT  ((uint8_t) 2)
typedef uint8_t MEDDEA_eCommandExecutionReturn_t;

/*
    Possible MEDDEA Modes
*/
#define MEDDEA_EMEDDEAMODES_MEDDEA_Off_Mode ((uint8_t) 0)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Safe_Mode ((uint8_t) 1)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Engineering_Mode ((uint8_t) 2)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Idle_Mode ((uint8_t) 3)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Depolarization_Mode ((uint8_t) 4)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Ramp_Mode ((uint8_t) 5)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Science_Mode ((uint8_t) 6)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Reduced_Science_Mode ((uint8_t) 7)
#define MEDDEA_EMEDDEAMODES_MEDDEA_Pulser_Calibration_Mode ((uint8_t) 8)
#define MEDDEA_EMEDDEAMODES_MAX_CNT  ((uint8_t) 9)
typedef uint8_t MEDDEA_eMEDDEAModes_t;

/*
    Bytes to be read and written to MeDDEA
*/
typedef struct {
    uint16_t u16RegID;
    uint16_t au16ReadwriteBytes[12];
} PACKED_STRUCT MEDDEA_sReadWriteMEDDEA_t;


typedef struct {
    MEDDEA_eMEDDEAModes_t eSetMode;
} PACKED_STRUCT MeddeasetMEDDEAModeRequestData_t;

typedef struct {
    MEDDEA_sReadWriteMEDDEA_t sWriteData;
} PACKED_STRUCT MeddeawriteMEDDEARequestData_t;


typedef struct {
    MEDDEA_eMEDDEAModes_t eCurrentMode;
} PACKED_STRUCT MeddeagetMEDDEAModeResponseData_t;

typedef struct {
    MEDDEA_eCommandExecutionReturn_t eOpResult;
    MEDDEA_eMEDDEAModes_t eCurrentMode;
} PACKED_STRUCT MeddeasetMEDDEAModeResponseData_t;

typedef struct {
    MEDDEA_eCommandExecutionReturn_t eOpResult;
} PACKED_STRUCT MeddeawriteMEDDEAResponseData_t;

typedef struct {
    MEDDEA_sReadWriteMEDDEA_t sReadData;
} PACKED_STRUCT MeddeareadMEDDEAResponseData_t;


#endif  // #ifndef __FP_MEDDEAPROTOCOLTYPES_H__

