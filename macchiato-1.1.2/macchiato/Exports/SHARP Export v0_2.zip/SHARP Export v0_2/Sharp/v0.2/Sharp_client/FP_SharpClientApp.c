/*!
********************************************************************************************
* @file FP_SharpClientApp.c
* @brief ClientApp implementation template generator
********************************************************************************************
* @version           interface Sharp v0.2
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SharpProtocolClient.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL

static void Sharp_getHealthInfoResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetHealthInfoResponseData_t* pResponseData);

static void Sharp_getSHIPInfoResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetSHIPInfoResponseData_t* pResponseData);

static void Sharp_setDetectorPowerResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetDetectorPowerResponseData_t* pResponseData);

static void Sharp_setSharpTimeResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetSharpTimeResponseData_t* pResponseData);

static void Sharp_setSharpDateResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetSharpDateResponseData_t* pResponseData);

static void Sharp_getSharpTimeDateResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetSharpTimeDateResponseData_t* pResponseData);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static Sharp_ClientApi_t SharpClientApiCtx =
{
  .Sharp_getHealthInfoResponseHandler = (pfSharp_getHealthInfoResponseHandler_t) Sharp_getHealthInfoResponseHandlerImpl,
  .Sharp_getSHIPInfoResponseHandler = (pfSharp_getSHIPInfoResponseHandler_t) Sharp_getSHIPInfoResponseHandlerImpl,
  .Sharp_setDetectorPowerResponseHandler = (pfSharp_setDetectorPowerResponseHandler_t) Sharp_setDetectorPowerResponseHandlerImpl,
  .Sharp_setSharpTimeResponseHandler = (pfSharp_setSharpTimeResponseHandler_t) Sharp_setSharpTimeResponseHandlerImpl,
  .Sharp_setSharpDateResponseHandler = (pfSharp_setSharpDateResponseHandler_t) Sharp_setSharpDateResponseHandlerImpl,
  .Sharp_getSharpTimeDateResponseHandler = (pfSharp_getSharpTimeDateResponseHandler_t) Sharp_getSharpTimeDateResponseHandlerImpl,
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Response handler for method Sharp::getHealthInfo (ID = 0x00000001)
static void Sharp_getHealthInfoResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetHealthInfoResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::getHealthInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getHealthInfo@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::getHealthInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getHealthInfo@
    }
}
// @END@ Response handler for method Sharp::getHealthInfo (ID = 0x00000001)

// @START@ Response handler for method Sharp::getSHIPInfo (ID = 0x00000002)
static void Sharp_getSHIPInfoResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetSHIPInfoResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::getSHIPInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSHIPInfo@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::getSHIPInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSHIPInfo@
    }
}
// @END@ Response handler for method Sharp::getSHIPInfo (ID = 0x00000002)

// @START@ Response handler for method Sharp::setDetectorPower (ID = 0x00000003)
static void Sharp_setDetectorPowerResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetDetectorPowerResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::setDetectorPower@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setDetectorPower@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::setDetectorPower@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setDetectorPower@
    }
}
// @END@ Response handler for method Sharp::setDetectorPower (ID = 0x00000003)

// @START@ Response handler for method Sharp::setSharpTime (ID = 0x00000004)
static void Sharp_setSharpTimeResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetSharpTimeResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::setSharpTime@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setSharpTime@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::setSharpTime@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setSharpTime@
    }
}
// @END@ Response handler for method Sharp::setSharpTime (ID = 0x00000004)

// @START@ Response handler for method Sharp::setSharpDate (ID = 0x00000005)
static void Sharp_setSharpDateResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpsetSharpDateResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::setSharpDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::setSharpDate@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::setSharpDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::setSharpDate@
    }
}
// @END@ Response handler for method Sharp::setSharpDate (ID = 0x00000005)

// @START@ Response handler for method Sharp::getSharpTimeDate (ID = 0x00000006)
static void Sharp_getSharpTimeDateResponseHandlerImpl(RespContext_t* pRespCtx,
            const SharpgetSharpTimeDateResponseData_t* pResponseData)
{
    // @USER_VAR_SECTION_START@Sharp::getSharpTimeDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSharpTimeDate@

    if ((pRespCtx != NULL) && (pResponseData != NULL))
    {
        // @USER_CODE_SECTION_START@Sharp::getSharpTimeDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSharpTimeDate@
    }
}
// @END@ Response handler for method Sharp::getSharpTimeDate (ID = 0x00000006)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void SharpClientAppInit(void)
{
    Sharp_registerClientApi(&SharpClientApiCtx);
}
