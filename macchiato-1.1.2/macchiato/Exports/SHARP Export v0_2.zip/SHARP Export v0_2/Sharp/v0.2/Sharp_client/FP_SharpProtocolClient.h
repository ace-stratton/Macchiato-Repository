/*!
********************************************************************************************
* @file FP_SharpProtocolClient.h
* @brief ESSA Stack client-side public API declaration
********************************************************************************************
* @version           interface Sharp v0.2
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SHARPPROTOCOLCLIENT_H__
#define __FP_SHARPPROTOCOLCLIENT_H__

#include "FP_SharpProtocolTypes.h"

/**********************************************************************
 *
 *  Type definitions
 *
 **********************************************************************/
typedef void (*pfSharp_getHealthInfoResponseHandler_t)(RespContext_t *pRespCtx,
              SharpgetHealthInfoResponseData_t *pResponseData);

typedef void (*pfSharp_getSHIPInfoResponseHandler_t)(RespContext_t *pRespCtx,
              SharpgetSHIPInfoResponseData_t *pResponseData);

typedef void (*pfSharp_setDetectorPowerResponseHandler_t)(RespContext_t *pRespCtx,
              SharpsetDetectorPowerResponseData_t *pResponseData);

typedef void (*pfSharp_setSharpTimeResponseHandler_t)(RespContext_t *pRespCtx,
              SharpsetSharpTimeResponseData_t *pResponseData);

typedef void (*pfSharp_setSharpDateResponseHandler_t)(RespContext_t *pRespCtx,
              SharpsetSharpDateResponseData_t *pResponseData);

typedef void (*pfSharp_getSharpTimeDateResponseHandler_t)(RespContext_t *pRespCtx,
              SharpgetSharpTimeDateResponseData_t *pResponseData);


typedef struct {
    pfSharp_getHealthInfoResponseHandler_t Sharp_getHealthInfoResponseHandler;
    pfSharp_getSHIPInfoResponseHandler_t Sharp_getSHIPInfoResponseHandler;
    pfSharp_setDetectorPowerResponseHandler_t Sharp_setDetectorPowerResponseHandler;
    pfSharp_setSharpTimeResponseHandler_t Sharp_setSharpTimeResponseHandler;
    pfSharp_setSharpDateResponseHandler_t Sharp_setSharpDateResponseHandler;
    pfSharp_getSharpTimeDateResponseHandler_t Sharp_getSharpTimeDateResponseHandler;
} Sharp_ClientApi_t;

/**********************************************************************
 *
 *  Client protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_SharpProtocolClientInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void Sharp_registerClientApi(Sharp_ClientApi_t *pCliApiHandlers);

// @deprecated - will be removed in the future - use FP_SharpProtocolClientInfo directly
ESSA_pStack_FunctionProtocolInfo_t Sharp_getClientProtocolDescriptor(void);

ESSATMAC_ErrCodes Sharp_getHealthInfoReq(
                ReqContext_t* ctx);

ESSATMAC_ErrCodes Sharp_getSHIPInfoReq(
                ReqContext_t* ctx);

ESSATMAC_ErrCodes Sharp_setDetectorPowerReq(
                ReqContext_t* ctx,
                const uint32_t u32DetectorID,
                const SHARP_DetectorPower_t eOnOff
);

ESSATMAC_ErrCodes Sharp_setSharpTimeReq(
                ReqContext_t* ctx,
                const bool bGNSS,
                const SHARP_stime_t * const sTime
);

ESSATMAC_ErrCodes Sharp_setSharpDateReq(
                ReqContext_t* ctx,
                const bool bGNSS,
                const SHARP_sdate_t * const sDate
);

ESSATMAC_ErrCodes Sharp_getSharpTimeDateReq(
                ReqContext_t* ctx);


#endif  // #ifndef __FP_SHARPPROTOCOLCLIENT_H__

