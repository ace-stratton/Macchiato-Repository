/*!
********************************************************************************************
* @file FP_MeddeaProtocolServer.h
* @brief ESSA Stack server-side public API declaration
********************************************************************************************
* @version           interface Meddea v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_MEDDEAPROTOCOLSERVER_H__
#define __FP_MEDDEAPROTOCOLSERVER_H__

#include "FP_MeddeaProtocolTypes.h"

typedef void (*pfMeddea_getMEDDEAModeRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfMeddea_setMEDDEAModeRequestHandler_t)(ReqContext_t *ctx, MeddeasetMEDDEAModeRequestData_t *pRequestData);
typedef void (*pfMeddea_setMEDDEATimeRequestHandler_t)(ReqContext_t *ctx, MeddeasetMEDDEATimeRequestData_t *pRequestData);
typedef void (*pfMeddea_setMEDDEADateRequestHandler_t)(ReqContext_t *ctx, MeddeasetMEDDEADateRequestData_t *pRequestData);
typedef void (*pfMeddea_getMEDDEATimeDateRequestHandler_t)(ReqContext_t *ctx);

typedef struct {
    pfMeddea_getMEDDEAModeRequestHandler_t Meddea_getMEDDEAModeRequestHandler;
    pfMeddea_setMEDDEAModeRequestHandler_t Meddea_setMEDDEAModeRequestHandler;
    pfMeddea_setMEDDEATimeRequestHandler_t Meddea_setMEDDEATimeRequestHandler;
    pfMeddea_setMEDDEADateRequestHandler_t Meddea_setMEDDEADateRequestHandler;
    pfMeddea_getMEDDEATimeDateRequestHandler_t Meddea_getMEDDEATimeDateRequestHandler;
} Meddea_ServerApi_t;

/**********************************************************************
 *
 *  Server protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_MeddeaProtocolServerInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void Meddea_registerServerApi(Meddea_ServerApi_t *pSrvApiHandlers);

// @deprecated - will be removed in the future - use FP_MeddeaProtocolServerInfo directly
ESSA_pStack_FunctionProtocolInfo_t Meddea_getServerProtocolDescriptor(void);

ESSATMAC_ErrCodes Meddea_getMEDDEAModeResp(
                RespContext_t* ctx,
                const MEDDEA_sMEDDEAParameters_t * const sParameters,
                const MEDDEA_eMEDDEAModes_t eMode
);

ESSATMAC_ErrCodes Meddea_setMEDDEAModeResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eOpResult,
                const MEDDEA_sMEDDEAParameters_t * const sParameters,
                const MEDDEA_eMEDDEAModes_t eMode
);

ESSATMAC_ErrCodes Meddea_setMEDDEATimeResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes Meddea_setMEDDEADateResp(
                RespContext_t* ctx,
                const MEDDEA_eCommandExecutionReturn_t eExecutionSuccess
);

ESSATMAC_ErrCodes Meddea_getMEDDEATimeDateResp(
                RespContext_t* ctx,
                const MEDDEA_stime_t * const sTime,
                const MEDDEA_sdate_t * const sDate
);


#endif  // #ifndef __FP_MEDDEAPROTOCOLSERVER_H__
