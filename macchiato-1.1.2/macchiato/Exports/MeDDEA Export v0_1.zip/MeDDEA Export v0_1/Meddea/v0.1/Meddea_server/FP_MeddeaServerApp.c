/*!
********************************************************************************************
* @file FP_MeddeaServerApp.c
* @brief ServerApp implementation template generator
********************************************************************************************
* @version           interface Meddea v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_MeddeaProtocolServer.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL
static void Meddea_getMEDDEAModeRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Meddea_setMEDDEAModeRequestHandlerImpl(ReqContext_t* pReqCtx,
            const MeddeasetMEDDEAModeRequestData_t* pRequestData);

static void Meddea_setMEDDEATimeRequestHandlerImpl(ReqContext_t* pReqCtx,
            const MeddeasetMEDDEATimeRequestData_t* pRequestData);

static void Meddea_setMEDDEADateRequestHandlerImpl(ReqContext_t* pReqCtx,
            const MeddeasetMEDDEADateRequestData_t* pRequestData);

static void Meddea_getMEDDEATimeDateRequestHandlerImpl(ReqContext_t* pReqCtx);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static Meddea_ServerApi_t MeddeaServerApiCtx =
{
  .Meddea_getMEDDEAModeRequestHandler = (pfMeddea_getMEDDEAModeRequestHandler_t) Meddea_getMEDDEAModeRequestHandlerImpl,
  .Meddea_setMEDDEAModeRequestHandler = (pfMeddea_setMEDDEAModeRequestHandler_t) Meddea_setMEDDEAModeRequestHandlerImpl,
  .Meddea_setMEDDEATimeRequestHandler = (pfMeddea_setMEDDEATimeRequestHandler_t) Meddea_setMEDDEATimeRequestHandlerImpl,
  .Meddea_setMEDDEADateRequestHandler = (pfMeddea_setMEDDEADateRequestHandler_t) Meddea_setMEDDEADateRequestHandlerImpl,
  .Meddea_getMEDDEATimeDateRequestHandler = (pfMeddea_getMEDDEATimeDateRequestHandler_t) Meddea_getMEDDEATimeDateRequestHandlerImpl
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Request handler for method Meddea::getMEDDEAMode (ID = 0x00000001)
static void Meddea_getMEDDEAModeRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    MEDDEA_sMEDDEAParameters_t sParameters;
    MEDDEA_eMEDDEAModes_t eMode;

    // @USER_VAR_SECTION_START@Meddea::getMEDDEAMode@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Meddea::getMEDDEAMode@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Meddea::getMEDDEAMode@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Meddea::getMEDDEAMode@

        respResult = Meddea_getMEDDEAModeResp(
                        &respCtx,
                        &sParameters,
                        eMode
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_MEDDEA, MEDDEA_GETMEDDEAMODE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Meddea::getMEDDEAMode (ID = 0x00000001)

// @START@ Request handler for method Meddea::setMEDDEAMode (ID = 0x00000002)
static void Meddea_setMEDDEAModeRequestHandlerImpl(ReqContext_t *pReqCtx,
            const MeddeasetMEDDEAModeRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    MEDDEA_eCommandExecutionReturn_t eOpResult;
    MEDDEA_sMEDDEAParameters_t sParameters;
    MEDDEA_eMEDDEAModes_t eMode;

    // @USER_VAR_SECTION_START@Meddea::setMEDDEAMode@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Meddea::setMEDDEAMode@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Meddea::setMEDDEAMode@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Meddea::setMEDDEAMode@

        respResult = Meddea_setMEDDEAModeResp(
                        &respCtx,
                        eOpResult,
                        &sParameters,
                        eMode
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_MEDDEA, MEDDEA_SETMEDDEAMODE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Meddea::setMEDDEAMode (ID = 0x00000002)

// @START@ Request handler for method Meddea::setMEDDEATime (ID = 0x00000003)
static void Meddea_setMEDDEATimeRequestHandlerImpl(ReqContext_t *pReqCtx,
            const MeddeasetMEDDEATimeRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    MEDDEA_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@Meddea::setMEDDEATime@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Meddea::setMEDDEATime@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Meddea::setMEDDEATime@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Meddea::setMEDDEATime@

        respResult = Meddea_setMEDDEATimeResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_MEDDEA, MEDDEA_SETMEDDEATIME_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Meddea::setMEDDEATime (ID = 0x00000003)

// @START@ Request handler for method Meddea::setMEDDEADate (ID = 0x00000004)
static void Meddea_setMEDDEADateRequestHandlerImpl(ReqContext_t *pReqCtx,
            const MeddeasetMEDDEADateRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    MEDDEA_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@Meddea::setMEDDEADate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Meddea::setMEDDEADate@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Meddea::setMEDDEADate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Meddea::setMEDDEADate@

        respResult = Meddea_setMEDDEADateResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_MEDDEA, MEDDEA_SETMEDDEADATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Meddea::setMEDDEADate (ID = 0x00000004)

// @START@ Request handler for method Meddea::getMEDDEATimeDate (ID = 0x00000005)
static void Meddea_getMEDDEATimeDateRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    MEDDEA_stime_t sTime;
    MEDDEA_sdate_t sDate;

    // @USER_VAR_SECTION_START@Meddea::getMEDDEATimeDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Meddea::getMEDDEATimeDate@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Meddea::getMEDDEATimeDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Meddea::getMEDDEATimeDate@

        respResult = Meddea_getMEDDEATimeDateResp(
                        &respCtx,
                        &sTime,
                        &sDate
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_MEDDEA, MEDDEA_GETMEDDEATIMEDATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Meddea::getMEDDEATimeDate (ID = 0x00000005)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void MeddeaServerAppInit(void)
{
    Meddea_registerServerApi(&MeddeaServerApiCtx);
}
