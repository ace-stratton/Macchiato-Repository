/*!
********************************************************************************************
* @file FP_SharpProtocolServer.h
* @brief ESSA Stack server-side public API declaration
********************************************************************************************
* @version           interface Sharp v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#ifndef __FP_SHARPPROTOCOLSERVER_H__
#define __FP_SHARPPROTOCOLSERVER_H__

#include "FP_SharpProtocolTypes.h"

typedef void (*pfSharp_getHealthInfoRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_getSHIPInfoRequestHandler_t)(ReqContext_t *ctx);
typedef void (*pfSharp_SetDetectorPowerRequestHandler_t)(ReqContext_t *ctx, SharpSetDetectorPowerRequestData_t *pRequestData);

typedef struct {
    pfSharp_getHealthInfoRequestHandler_t Sharp_getHealthInfoRequestHandler;
    pfSharp_getSHIPInfoRequestHandler_t Sharp_getSHIPInfoRequestHandler;
    pfSharp_SetDetectorPowerRequestHandler_t Sharp_SetDetectorPowerRequestHandler;
} Sharp_ServerApi_t;

/**********************************************************************
 *
 *  Server protocol ESSA descriptor
 *
 **********************************************************************/
extern const ESSA_Stack_FunctionProtocolInfo_t FP_SharpProtocolServerInfo;

/**********************************************************************
 *
 *  Public methods
 *
 **********************************************************************/
void Sharp_registerServerApi(Sharp_ServerApi_t *pSrvApiHandlers);

// @deprecated - will be removed in the future - use FP_SharpProtocolServerInfo directly
ESSA_pStack_FunctionProtocolInfo_t Sharp_getServerProtocolDescriptor(void);

ESSATMAC_ErrCodes Sharp_getHealthInfoResp(
                RespContext_t* ctx,
                const SHARP_sdate_t * const sDate,
                const SHARP_stime_t * const sTime,
                const SHARP_sfaultstate_t * const sFaults,
                const SHARP_sDetectorTemps_t * const sTemperatures,
                const SHARP_sDetectorVoltages_t * const sVoltages,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
);

ESSATMAC_ErrCodes Sharp_getSHIPInfoResp(
                RespContext_t* ctx,
                const SHARP_sSHIPVersion_t * const sVersioning,
                const SHARP_sFPGAVersion_t * const sFpga_versioning,
                const SHARP_sSHIPStorage_t * const sShipStorage,
                const SHARP_sSHIPPower_t * const sShipPower
);

ESSATMAC_ErrCodes Sharp_SetDetectorPowerResp(
                RespContext_t* ctx,
                const SHARP_DetectorPower_t eOpResult,
                const SHARP_sDetectorStatus_t * const sDetectorStatus
);


#endif  // #ifndef __FP_SHARPPROTOCOLSERVER_H__
