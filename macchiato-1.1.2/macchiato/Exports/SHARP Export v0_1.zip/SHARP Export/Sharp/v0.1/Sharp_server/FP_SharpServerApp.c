/*!
********************************************************************************************
* @file FP_SharpServerApp.c
* @brief ServerApp implementation template generator
********************************************************************************************
* @version           interface Sharp v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_SharpProtocolServer.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL
static void Sharp_getHealthInfoRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_getSHIPInfoRequestHandlerImpl(ReqContext_t* pReqCtx);

static void Sharp_SetDetectorPowerRequestHandlerImpl(ReqContext_t* pReqCtx,
            const SharpSetDetectorPowerRequestData_t* pRequestData);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static Sharp_ServerApi_t SharpServerApiCtx =
{
  .Sharp_getHealthInfoRequestHandler = (pfSharp_getHealthInfoRequestHandler_t) Sharp_getHealthInfoRequestHandlerImpl,
  .Sharp_getSHIPInfoRequestHandler = (pfSharp_getSHIPInfoRequestHandler_t) Sharp_getSHIPInfoRequestHandlerImpl,
  .Sharp_SetDetectorPowerRequestHandler = (pfSharp_SetDetectorPowerRequestHandler_t) Sharp_SetDetectorPowerRequestHandlerImpl
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Request handler for method Sharp::getHealthInfo (ID = 0x00000001)
static void Sharp_getHealthInfoRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_sdate_t sDate;
    SHARP_stime_t sTime;
    SHARP_sfaultstate_t sFaults;
    SHARP_sDetectorTemps_t sTemperatures;
    SHARP_sDetectorVoltages_t sVoltages;
    SHARP_sDetectorStatus_t sDetectorStatus;

    // @USER_VAR_SECTION_START@Sharp::getHealthInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getHealthInfo@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getHealthInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getHealthInfo@

        respResult = Sharp_getHealthInfoResp(
                        &respCtx,
                        &sDate,
                        &sTime,
                        &sFaults,
                        &sTemperatures,
                        &sVoltages,
                        &sDetectorStatus
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETHEALTHINFO_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getHealthInfo (ID = 0x00000001)

// @START@ Request handler for method Sharp::getSHIPInfo (ID = 0x00000002)
static void Sharp_getSHIPInfoRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_sSHIPVersion_t sVersioning;
    SHARP_sFPGAVersion_t sFpga_versioning;
    SHARP_sSHIPStorage_t sShipStorage;
    SHARP_sSHIPPower_t sShipPower;

    // @USER_VAR_SECTION_START@Sharp::getSHIPInfo@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::getSHIPInfo@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::getSHIPInfo@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::getSHIPInfo@

        respResult = Sharp_getSHIPInfoResp(
                        &respCtx,
                        &sVersioning,
                        &sFpga_versioning,
                        &sShipStorage,
                        &sShipPower
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_GETSHIPINFO_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::getSHIPInfo (ID = 0x00000002)

// @START@ Request handler for method Sharp::SetDetectorPower (ID = 0x00000003)
static void Sharp_SetDetectorPowerRequestHandlerImpl(ReqContext_t *pReqCtx,
            const SharpSetDetectorPowerRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    SHARP_DetectorPower_t eOpResult;
    SHARP_sDetectorStatus_t sDetectorStatus;

    // @USER_VAR_SECTION_START@Sharp::SetDetectorPower@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@Sharp::SetDetectorPower@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@Sharp::SetDetectorPower@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@Sharp::SetDetectorPower@

        respResult = Sharp_SetDetectorPowerResp(
                        &respCtx,
                        eOpResult,
                        &sDetectorStatus
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_SHARP, SHARP_SETDETECTORPOWER_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method Sharp::SetDetectorPower (ID = 0x00000003)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void SharpServerAppInit(void)
{
    Sharp_registerServerApi(&SharpServerApiCtx);
}
