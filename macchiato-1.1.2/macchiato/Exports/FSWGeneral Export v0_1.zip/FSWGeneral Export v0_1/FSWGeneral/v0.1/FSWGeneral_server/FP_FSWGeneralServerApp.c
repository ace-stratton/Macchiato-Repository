/*!
********************************************************************************************
* @file FP_FSWGeneralServerApp.c
* @brief ServerApp implementation template generator
********************************************************************************************
* @version           interface FSWGeneral v0.1
*
* @copyright         (C) Copyright EnduroSat
*
*                    Contents and presentations are protected world-wide.
*                    Any kind of using, copying etc. is prohibited without prior permission.
*                    All rights - incl. industrial property rights - are reserved.
*
*-------------------------------------------------------------------------------------------
* GENERATOR: org.endurosat.generators.macchiato.binders.Gen_C v2.12
*-------------------------------------------------------------------------------------------
* !!! Please note that this code is fully GENERATED and shall not be manually modified as
* all changes will be overwritten !!!
********************************************************************************************
*/

#include "FP_FSWGeneralProtocolServer.h"

// @START_USER@ USER_INCLUDES
// Place user includes here to preserve them during merge!!!
// @END_USER@ USER_INCLUDES

/**********************************************************************
 *
 *  Local methods declarations
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_DECL
// Place static function declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_FUNC_DECL
static void FSWGeneral_setInstrumentTimeRequestHandlerImpl(ReqContext_t* pReqCtx,
            const FSWGeneralsetInstrumentTimeRequestData_t* pRequestData);

static void FSWGeneral_setInstrumentDateRequestHandlerImpl(ReqContext_t* pReqCtx,
            const FSWGeneralsetInstrumentDateRequestData_t* pRequestData);

static void FSWGeneral_getInstrumentTimeDateRequestHandlerImpl(ReqContext_t* pReqCtx);

static void FSWGeneral_getInstrumentModesRequestHandlerImpl(ReqContext_t* pReqCtx);

static void FSWGeneral_setInstrumentModesRequestHandlerImpl(ReqContext_t* pReqCtx,
            const FSWGeneralsetInstrumentModesRequestData_t* pRequestData);


/**********************************************************************
 *
 *  Local variables
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_VARS_DECL
// Place static variable declarations here to preserve them during merge!!!
// @END_USER@ USER_LOCAL_VARS_DECL

static FSWGeneral_ServerApi_t FSWGeneralServerApiCtx =
{
  .FSWGeneral_setInstrumentTimeRequestHandler = (pfFSWGeneral_setInstrumentTimeRequestHandler_t) FSWGeneral_setInstrumentTimeRequestHandlerImpl,
  .FSWGeneral_setInstrumentDateRequestHandler = (pfFSWGeneral_setInstrumentDateRequestHandler_t) FSWGeneral_setInstrumentDateRequestHandlerImpl,
  .FSWGeneral_getInstrumentTimeDateRequestHandler = (pfFSWGeneral_getInstrumentTimeDateRequestHandler_t) FSWGeneral_getInstrumentTimeDateRequestHandlerImpl,
  .FSWGeneral_getInstrumentModesRequestHandler = (pfFSWGeneral_getInstrumentModesRequestHandler_t) FSWGeneral_getInstrumentModesRequestHandlerImpl,
  .FSWGeneral_setInstrumentModesRequestHandler = (pfFSWGeneral_setInstrumentModesRequestHandler_t) FSWGeneral_setInstrumentModesRequestHandlerImpl
};

/**********************************************************************
 *
 *  Local methods implementation
 *
 **********************************************************************/
// @START_USER@ USER_LOCAL_FUNC_IMPL
// Place static functions implementation here to preserve it during merge!!!
// @END_USER@ USER_LOCAL_FUNC_IMPL

// @START@ Request handler for method FSWGeneral::setInstrumentTime (ID = 0x00000001)
static void FSWGeneral_setInstrumentTimeRequestHandlerImpl(ReqContext_t *pReqCtx,
            const FSWGeneralsetInstrumentTimeRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@FSWGeneral::setInstrumentTime@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@FSWGeneral::setInstrumentTime@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@FSWGeneral::setInstrumentTime@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@FSWGeneral::setInstrumentTime@

        respResult = FSWGeneral_setInstrumentTimeResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL, FSWGENERAL_SETINSTRUMENTTIME_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method FSWGeneral::setInstrumentTime (ID = 0x00000001)

// @START@ Request handler for method FSWGeneral::setInstrumentDate (ID = 0x00000002)
static void FSWGeneral_setInstrumentDateRequestHandlerImpl(ReqContext_t *pReqCtx,
            const FSWGeneralsetInstrumentDateRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    FSWGENERAL_eCommandExecutionReturn_t eExecutionSuccess;

    // @USER_VAR_SECTION_START@FSWGeneral::setInstrumentDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@FSWGeneral::setInstrumentDate@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@FSWGeneral::setInstrumentDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@FSWGeneral::setInstrumentDate@

        respResult = FSWGeneral_setInstrumentDateResp(
                        &respCtx,
                        eExecutionSuccess
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL, FSWGENERAL_SETINSTRUMENTDATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method FSWGeneral::setInstrumentDate (ID = 0x00000002)

// @START@ Request handler for method FSWGeneral::getInstrumentTimeDate (ID = 0x00000003)
static void FSWGeneral_getInstrumentTimeDateRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    FSWGENERAL_eMatch_t eMatch;
    FSWGENERAL_stime_t sTimeSharp;
    FSWGENERAL_sdate_t sDateSharp;
    FSWGENERAL_stime_t sTimeMeddea;
    FSWGENERAL_sdate_t sDateMeddea;

    // @USER_VAR_SECTION_START@FSWGeneral::getInstrumentTimeDate@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@FSWGeneral::getInstrumentTimeDate@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@FSWGeneral::getInstrumentTimeDate@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@FSWGeneral::getInstrumentTimeDate@

        respResult = FSWGeneral_getInstrumentTimeDateResp(
                        &respCtx,
                        eMatch,
                        &sTimeSharp,
                        &sDateSharp,
                        &sTimeMeddea,
                        &sDateMeddea
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL, FSWGENERAL_GETINSTRUMENTTIMEDATE_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method FSWGeneral::getInstrumentTimeDate (ID = 0x00000003)

// @START@ Request handler for method FSWGeneral::getInstrumentModes (ID = 0x00000004)
static void FSWGeneral_getInstrumentModesRequestHandlerImpl(ReqContext_t* pReqCtx)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    FSWGENERAL_eSHARPModes_t eModeSharp;
    FSWGENERAL_eMEDDEAModes_t eModeMeddea;

    // @USER_VAR_SECTION_START@FSWGeneral::getInstrumentModes@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@FSWGeneral::getInstrumentModes@

    if (pReqCtx != NULL)
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@FSWGeneral::getInstrumentModes@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@FSWGeneral::getInstrumentModes@

        respResult = FSWGeneral_getInstrumentModesResp(
                        &respCtx,
                        eModeSharp,
                        eModeMeddea
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL, FSWGENERAL_GETINSTRUMENTMODES_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method FSWGeneral::getInstrumentModes (ID = 0x00000004)

// @START@ Request handler for method FSWGeneral::setInstrumentModes (ID = 0x00000005)
static void FSWGeneral_setInstrumentModesRequestHandlerImpl(ReqContext_t *pReqCtx,
            const FSWGeneralsetInstrumentModesRequestData_t* pRequestData)
{
    ESSATMAC_ErrCodes respResult;
    RespContext_t respCtx;
    FSWGENERAL_eCommandExecutionReturn_t eOpResult;
    FSWGENERAL_eSHARPModes_t eModeSharp;
    FSWGENERAL_eMEDDEAModes_t eModeMeddea;

    // @USER_VAR_SECTION_START@FSWGeneral::setInstrumentModes@
    // Put your local variables in this section to preserve during merge!
    // @USER_VAR_SECTION_END@FSWGeneral::setInstrumentModes@

    if ((pReqCtx != NULL) && (pRequestData != NULL))
    {
        respCtx.nInterfaceNumber = pReqCtx->nInterfaceNumber;
        respCtx.netType = pReqCtx->netType;
        respCtx.nAddr = pReqCtx->nAddr;
        respCtx.seqId = pReqCtx->seqId;

        // @USER_CODE_SECTION_START@FSWGeneral::setInstrumentModes@
        
        // TODO: Put your implementation to handle the
        // received server response here!
        
        // @USER_CODE_SECTION_END@FSWGeneral::setInstrumentModes@

        respResult = FSWGeneral_setInstrumentModesResp(
                        &respCtx,
                        eOpResult,
                        eModeSharp,
                        eModeMeddea
                     );

        if (respResult != ESSATMAC_EC_OK)
            TRACE_ERROR(ES_SAT_FUNC_PROTOCOL_ID_FSWGENERAL, FSWGENERAL_SETINSTRUMENTMODES_FUNCRESP_ID, respResult);
    }
}
// @END@ Request handler for method FSWGeneral::setInstrumentModes (ID = 0x00000005)


/**********************************************************************
 *
 *  Public functions
 *
 **********************************************************************/
void FSWGeneralServerAppInit(void)
{
    FSWGeneral_registerServerApi(&FSWGeneralServerApiCtx);
}
